import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-05
*/

public class CommercialWebsites 
{
    public static void main(String[] args) 
    {
        
        Scanner in = new Scanner(System.in);

        // Initialize a counter to keep track of the number of commercial websites entered
        int Count = 0;

        // Initialize a boolean variable to control the loop
        boolean end = false;

        System.out.println("<Type \"stop\" to end the program>");

        // Continue to prompt the user to enter web addresses until they type "stop"
        while (!end) 
        {
            System.out.print("Enter a web address: ");

            String input = in.nextLine().trim().toLowerCase();

            // Check if the user typed "stop"
            if (input.equals("stop")) 
            {

                end = true;
            } 
            else 
            {
                // If the user didn't type "stop", check if the input is a commercial website
                if (input.endsWith(".com") && input.length() > 4 
                    && input.lastIndexOf('.') == input.length() - 4) 
                    {
                    Count++;
                    }
            }
        }
        System.out.printf("The number of commercial websites entered is %d.\n", Count);
    }
}

