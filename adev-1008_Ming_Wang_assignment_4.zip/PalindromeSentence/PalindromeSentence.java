import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-05
*/

public class PalindromeSentence 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        // Prompt the user to enter a sentence
        System.out.print("Enter a sentence: ");
        String input = in.nextLine();

        // Loop through the input and create a new string containing only letters
        String letters = "";
        for (int i = 0; i < input.length(); i++) 
        {
            char c = input.charAt(i);
            if (Character.isLetter(c)) 
            {
                letters += Character.toLowerCase(c);
            }
        }

        // Loop through the lettersOnly string and check if it is a palindrome
        boolean isPalindrome = true;
        int i = 0, j = letters.length() - 1;
        while (i < j && isPalindrome) 
        {
            if (letters.charAt(i) != letters.charAt(j)) 
            {
                isPalindrome = false;
            }
            i++;
            j--;
        }

        // Output whether the input is a palindrome or not
        if (isPalindrome) 
        {
            System.out.println("The sentence is a palindrome.");
        } 
        else 
        {
            System.out.println("The sentence is not a palindrome.");
        }
    }
}
