import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-05
*/

public class AreaOfRoomCalculator 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        boolean endProgram = false;

        // Loop until user decides to end program
        while (!endProgram) 
        {
            int length = -1;
            int width = -1;
            boolean lengthEntered = false;
            boolean widthEntered = false;

            // Loop until valid length is entered or user ends program
            while (!lengthEntered && !endProgram) 
            {
                System.out.print("Enter the length of the room: ");
                length = in.nextInt();

                // Check if user wants to end program
                if (length == 0) 
                {
                    endProgram = true;
                } 
                // Check if entered length is valid
                else if (length >= 0) 
                {
                    lengthEntered = true;
                }
            }
            // Loop until valid width is entered or user ends program
            while (!widthEntered && lengthEntered && !endProgram) 
            {
                System.out.print("Enter the width of the room: ");
                width = in.nextInt();

                if (width == 0) 
                {
                    int area = length * length;
                    System.out.printf("The area of the room is %d.\n\n", area);
                    lengthEntered = false;
                    widthEntered = false;
                } 
                else if (width >= 0) 
                {
                    widthEntered = true;
                }
            }
            // Calculate and display area if both length and width are valid
            if (lengthEntered && widthEntered) 
            {
                int area = length * width;
                System.out.printf("The area of the room is %d.\n\n", area);
            }
        }
    }
}