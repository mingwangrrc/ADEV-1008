import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-05
*/

public class ExamGrades 
{
    public static void main(String[] args) 
    {
        
        Scanner in = new Scanner(System.in);

        // Initialize a new integer array of size 10 to store the exam grades
        int[] grades = new int[10];

        // count to keep track of how many grades have been entered, 
        // and sum to keep track of the total sum of the grades entered
        int count = 0;
        int sum = 0;

        // Continue to prompt the user to enter grades until 10 valid grades have been entered
        while (count < 10) 
        {
        
            System.out.print("Enter grade for student " + (count + 1) + ": ");

            int grade = in.nextInt();

            // Check if the grade is valid (between 0 and 100)
            if (grade >= 0 && grade <= 100) 
            {
                grades[count] = grade;
                count++;
                sum += grade;
            } 
            else 
            {

                System.out.print("Invalid grade. Enter again: ");
            }
        }

        // Initialize variables to store the minimum and maximum grades
        int min = grades[0];
        int max = grades[0];

        // Iterate over the grades array to find the minimum and maximum grades
        for (int i = 1; i < grades.length; i++) {
            if (grades[i] < min) 
            {
                min = grades[i];
            }
            if (grades[i] > max) 
            {
                max = grades[i];
            }
        }

        // Calculate the average grade
        double average = (double) sum / grades.length;

        System.out.println("The lowest grade is " + min + ".");
        System.out.println("The highest grade is " + max + ".");
        System.out.println("The average grade is " + String.format("%.5f", average) + ".");
    }
}
