import java.util.Arrays;
/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-22
* Updated: 2023-04-09
*/

/**
 * TeamStatsManager
 * @author Ming Wang
 * @version 1.0
 */
public class TeamShotOnGoalPercentagesTests 
{

    public static void main(String[] args) 
    {
        testConstructorWithNumberOfPlayers();
        testConstructorWithPercentagesArray();
        testGetPercentages();
        testSetPercentages();
        testGetSortedPercentages();
        testGetLowestPercentage();
        testGetAverageOfTopPlayers();
        testToString();
        
    }

    private static void testConstructorWithNumberOfPlayers() 
    {
        // Test 1: TeamShotOnGoalPercentages(int)
        System.out.println("TeamShotOnGoalPercentages(int)");
        System.out.println("Test #1 - Initialize percentages array without data.");
        TeamShotOnGoalPercentages test1 = new TeamShotOnGoalPercentages(4);
        System.out.println("Expected: [0.0, 0.0, 0.0, 0.0]");
        System.out.println("Actual:   " + Arrays.toString(test1.getPercentages()));
        System.out.println();
    }

    private static void testConstructorWithPercentagesArray() 
    {
        // Test 2: TeamShotOnGoalPercentages(double[])
        System.out.println("TeamShotOnGoalPercentages(double[])");
        System.out.println("Test #2 - Initialize percentages array with data.");
        TeamShotOnGoalPercentages test2 = new TeamShotOnGoalPercentages(new double[]{0.1, 0.2, 0.3, 0.4});
        System.out.println("Expected: [0.1, 0.2, 0.3, 0.4]");
        System.out.println("Actual:   " + Arrays.toString(test2.getPercentages()));
        System.out.println();
    }

    private static void testGetPercentages() 
    {
        // Test 3: getPercentages() : double[]
        System.out.println("getPercentages() : double[]");
        System.out.println("Test #3 - Returns a copy of the array used to initialize the object.");
        double[] percentages = new double[]{0.1, 0.2, 0.3, 0.4};
        TeamShotOnGoalPercentages test3 = new TeamShotOnGoalPercentages(percentages);
        System.out.println("Expected: The hash code of the percentages array used to initialize the object is different than the hashcode of the array returned by the getPercentages() method.");
        System.out.println("Actual:   " + percentages.hashCode() + " " + test3.getPercentages().hashCode());
        System.out.println();
    }

    private static void testSetPercentages() 
    {
        // Test 4: setPercentages(double[]) : void
        System.out.println("setPercentages(double[]) : void");
        System.out.println("Test #4 - Updates the state of the percentages.");
        TeamShotOnGoalPercentages test4 = new TeamShotOnGoalPercentages(4);
        test4.setPercentages(new double[]{0.5, 0.6, 0.7, 0.8});
        System.out.println("Expected: [0.5, 0.6, 0.7, 0.8]");
        System.out.println("Actual:   " + Arrays.toString(test4.getPercentages()));
        System.out.println();
    }

    private static void testGetSortedPercentages() 
    {
        // Test 5: getSortedPercentages() : double[]
        System.out.println("getSortedPercentages() : double[]");
        System.out.println("Test #5 - Returns a copy of the percentages array sorted in descending order.");
        TeamShotOnGoalPercentages test5 = new TeamShotOnGoalPercentages(new double[]{0.1, 0.4, 0.2, 0.3});
        System.out.println("Expected: [0.4, 0.3, 0.2, 0.1]");
        System.out.println("Actual:   " + Arrays.toString(test5.getSortedPercentages()));
        System.out.println();
    }

    private static void testGetLowestPercentage() 
    {
        // Test 6: getLowestPercentage() : double
        System.out.println("getLowestPercentage() : double");
        System.out.println("Test #6 - Returns the correct lowest percentage value.");
        TeamShotOnGoalPercentages test6 = new TeamShotOnGoalPercentages(new double[]{0.1, 0.4, 0.2, 0.3});
        System.out.println("Expected: 0.1");
        System.out.println("Actual:   " + test6.getLowestPercentage());
        System.out.println();
    }

    private static void testGetAverageOfTopPlayers() 
    {
        // Test 7: getAverageOfTopPlayers() : double
        System.out.println("getAverageOfTopPlayers() : double");
        System.out.println("Test #7 - Returns the correct average of the top five players where the number of players is greater than 5.");
        TeamShotOnGoalPercentages test7 = new TeamShotOnGoalPercentages(new double[]{0.1, 0.4, 0.5, 0.6, 0.7, 0.8});
        System.out.println("Expected: 0.6");
        System.out.println("Actual: " + test7.getAverageOfTopPlayers());
        System.out.println();

        System.out.println("Test #8 - Returns the correct average of the top five players where the number of players is less than 5.");
        TeamShotOnGoalPercentages test7b = new TeamShotOnGoalPercentages(new double[]{0.1, 0.4, 0.5, 0.6});
        System.out.println("Expected: 0.4");
        System.out.println("Actual:   " + test7b.getAverageOfTopPlayers());
        System.out.println();
    }

    private static void testToString() 
    {
        // Test 8: toString() : String
        System.out.println("toString() : String");
        System.out.println("Test #9 - Returns the correct String representation.");
        TeamShotOnGoalPercentages test8 = new TeamShotOnGoalPercentages(new double[]{0.1, 0.2, 0.3, 0.4});
        String expectedString = "--------------------\n" +
                "Player        SOG%\n" +
                "--------------------\n" +
                "1             0.1\n" +
                "2             0.2\n" +
                "3             0.3\n" +
                "4             0.4";
        System.out.println("Expected: \n" + expectedString);
        System.out.println("Actual:   \n" + test8.toString());
        System.out.println();
    }
}
