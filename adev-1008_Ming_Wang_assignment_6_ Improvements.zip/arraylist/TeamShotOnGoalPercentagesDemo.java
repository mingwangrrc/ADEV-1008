import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-22
* Updated: 2023-04-09
*/

/**
 * TeamStatsManager
 * @author Ming Wang
 * @version 1.0
 */
public class TeamShotOnGoalPercentagesDemo 
{

    public static void main(String[] args) 
    {
        ArrayList<TeamShotOnGoalPercentages> teams = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter the number of players per team: ");
        int numberOfPlayers = in.nextInt();

        // Add three new TeamShotOnGoalPercentages objects with random values
        for (int i = 0; i < 3; i++) 
        {
            double[] percentages = new double[numberOfPlayers];
            for (int j = 0; j < numberOfPlayers; j++) 
            {
                percentages[j] = random.nextDouble();
            }
            teams.add(new TeamShotOnGoalPercentages(percentages));
        }

        // Print each TeamShotOnGoalPercentages object using an enhanced for loop
        for (TeamShotOnGoalPercentages team : teams) 
        {
            System.out.println(team);
            System.out.println();
        }

        // Print the last element before removing it
        System.out.println("LAST ELEMENT BEFORE REMOVE:");
        System.out.println(teams.get(teams.size() - 1));

        // Remove the last element
        teams.remove(teams.size() - 1);

        // Print the last element after removing and trimming the ArrayList
        System.out.println("LAST ELEMENT AFTER REMOVE:");
        if (!teams.isEmpty()) 
        {
            System.out.println(teams.get(teams.size() - 1));
        } 
        else 
        {
            System.out.println("ArrayList is empty.");
        }
    }
}