import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-08
* Updated: 2023-02-13
*/

public class WebAddress {
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        // Prompt the user to enter a web address
        System.out.print("Enter a web address: ");

        // Read the web address as a string
        String webAddress = in.nextLine().toLowerCase();

        // Extract the top-level domain of the web address
        String Domain = webAddress.substring(webAddress.lastIndexOf("."));

        //identify the type of entity based on the domain
        switch (Domain) 
        {
            case ".gov":
                System.out.println("The address is for a government.");
                break;

            case ".edu":
                System.out.println("The address is for a university.");
                break;

            case ".com":
                System.out.println("The address is for a business.");
                break;

            case ".org":
                System.out.println("The address is for an organization.");
                break;

            default:
                System.out.println("The address is for another entity.");
                break;
        }
    }
}
