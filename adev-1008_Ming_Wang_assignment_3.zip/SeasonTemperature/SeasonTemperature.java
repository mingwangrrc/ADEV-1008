import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-08
* Updated: 2023-02-13
*/

public class SeasonTemperature {
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        // Prompt the user to enter a temperature
        System.out.print("Enter a temperature: ");

        // Read the temperature as an integer
        int temperature = in.nextInt();

        //identify the season based on the temperature
        if (temperature >= 90) {
            System.out.println("It is probably summer.");
        } 

        else if (temperature >= 70 && temperature < 90) {
            System.out.println("It is probably spring.");
        } 

        else if (temperature >= 50 && temperature < 70) {
            System.out.println("It is probably fall.");
        } 

        else if (temperature < 50) {
            System.out.println("It is probably winter.");
        } 

        else {
            System.out.println("The temperature entered is outside the valid range.");
        }
    }
}




