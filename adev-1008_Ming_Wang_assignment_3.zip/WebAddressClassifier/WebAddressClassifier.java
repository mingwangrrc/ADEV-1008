import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-08
* Updated: 2023-02-13
*/


public class WebAddressClassifier {

    public static void main(String[] args) 
    {

        Scanner in = new Scanner(System.in);

        // Prompt the user to enter a web address
        System.out.print("Enter a web address: ");

        // Read the web address as a string
        String webAddress = in.nextLine().toLowerCase();

        //identify the type of entity based on the top-level domain
        if (webAddress.endsWith(".gov")) {
            System.out.println("The address is for a government.");

        } else if (webAddress.endsWith(".edu")) {
            System.out.println("The address is for a university.");

        } else if (webAddress.endsWith(".com")) {
            System.out.println("The address is for a business.");

        } else if (webAddress.endsWith(".org")) {
            System.out.println("The address is for an organization.");

        } else {
            System.out.println("The address is for another entity.");
            
        }
    }
}