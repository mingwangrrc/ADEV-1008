import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-08
* Updated: 2023-03-03
*/

public class SeasonTemperature 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        // Prompt the user to enter a temperature
        System.out.print("Enter a temperature: ");

        // Read the temperature as an integer
        int temperature = in.nextInt();

        final int UPPER_INVALID = 110;
        final int LOWER_INVALID = -5;
        final int SUMMER_TEMP = 90;
        final int SPRING_TEMP= 70;
        final int FALL_TEMP = 50;

        //identify the season based on the temperature
        if (temperature >= LOWER_INVALID && temperature <= UPPER_INVALID) 
        {
            if (temperature >= SUMMER_TEMP) 
            {
                System.out.println("The season is summer.");
            } 
            
            else if (temperature >= SPRING_TEMP) 
            {
                System.out.println("The season is spring.");
            } 
            
            else if (temperature >= FALL_TEMP) 
            {
                System.out.println("The season is fall.");
            } 
            
            else 
            {
                System.out.println("The season is winter.");
            }

        } 
        else 
        {
            System.out.println("The temperature is out of range.");
        }
    }
}