import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-08
* Updated: 2023-03.03
*/

public class AdminLogin {
    public static void main(String[] args) 
    {

        Scanner in = new Scanner(System.in);

        // Prompt the user to enter their username
        System.out.print("Enter username: ");
        // Read the username as a string
        String username = in.nextLine();

        // Prompt the user to enter their password
        System.out.print("Enter password: ");
        // Read the password as a string
        String password = in.nextLine();

        //verify if the login credentials are valid
        if (username.equals("admin"))
        {
            if (password.equals("open")) 
            {
                System.out.println("Welcome");
            }
            else
            {
                System.out.println("Wrong password");    
            }
        } 
        else if (password.equals("open")) 
        {
            System.out.println("Wrong user ID");
        } 
        else 
        {
            System.out.println("Sorry, wrong ID and password");
        }
    }
}