package library;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-15
* Updated: 2023-03-19
*/

/**
 * Weather Forecast Modules
 * @author Ming Wang
 * @version 1.0
 */
public enum SkyCondition 
{
    SUNNY,
    SNOWY,
    CLOUDY,
    RAINY
}
