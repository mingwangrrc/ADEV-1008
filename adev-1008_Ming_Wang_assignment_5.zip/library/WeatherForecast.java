package library;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-15
* Updated: 2023-03-19
*/

/**
 * Weather Forecast Modules
 * @author Ming Wang
 * @version 1.0
 */
public class WeatherForecast 
{
    // Instance variables for temperature and sky condition
    private int temperature;
    private SkyCondition skyCondition;

    // Constants for consistency factor and minimum/maximum temperature values
    public static final int CONSISTENCY_FACTOR = 32;
    public static final int MINIMUM_TEMPERATURE = -50;
    public static final int MAXIMUM_TEMPERATURE = 150;

    /**
     * Constructs a WeatherForecast object with default temperature and sunny sky condition.
     */
    public WeatherForecast() 
    {
        this.temperature = 70;
        this.skyCondition = SkyCondition.SUNNY;
    }

    /**
     * Constructs a WeatherForecast object with the given temperature and sunny sky condition.
     * If the temperature is outside of the allowed range, it is set to 0.
     * @param temperature The temperature set for the weather forecast.
     */
    public WeatherForecast(int temperature) 
    {
        if (temperature >= MINIMUM_TEMPERATURE && temperature <= MAXIMUM_TEMPERATURE) 
        {
            this.temperature = temperature;
        } 
        else 
        {
            this.temperature = 0;
        }
        this.skyCondition = SkyCondition.SUNNY;
    }

    /**
     * Returns the temperature of the weather forecast.
     * @return The temperature of the weather forecast.
     */
    public int getTemperature() 
    {
        return temperature;
    }

    /**
     * Sets the temperature of the weather forecast.
     * If the temperature is outside of the allowed range, it is not set.
     * @param temperature The temperature set for the weather forecast.
     */
    public void setTemperature(int temperature) 
    {
        if (temperature >= MINIMUM_TEMPERATURE && temperature <= MAXIMUM_TEMPERATURE) 
        {
            this.temperature = temperature;
        }
    }

    /**
     * Returns the sky condition of the weather forecast.
     * @return The sky condition of the weather forecast.
     */
    public SkyCondition getSkyCondition() 
    {
        return skyCondition;
    }

    /**
     * Sets the sky condition of the weather forecast.
     * @param skyCondition The sky condition set for the weather forecast.
     */
    public void setSkyCondition(SkyCondition skyCondition) 
    {
        this.skyCondition = skyCondition;
    }

    /**
     * Converts a temperature value in Fahrenheit to Celsius.
     * @param fahrenheit The temperature value in Fahrenheit to be converted to Celsius.
     * @return The temperature value in Celsius.
     */
    public int toCelsius(int fahrenheit) 
    {
        return (int) ((fahrenheit - 32) * 5.0 / 9.0);
    }

    /**
     * Checks if the temperature and sky condition are consistent.
     * Temperature should be at least CONSISTENCY_FACTOR for snowy sky condition
     * and less than CONSISTENCY_FACTOR for rainy sky condition.
     * @return True if temperature and sky condition are consistent, false otherwise.
     */
    public boolean isConsistent() 
    {
        if ((temperature >= CONSISTENCY_FACTOR && skyCondition == SkyCondition.SNOWY) ||
                (temperature < CONSISTENCY_FACTOR && skyCondition == SkyCondition.RAINY)) 
                {
            return false;
        } 
        else 
        {
            return true;
        }
    }

    /**
     * Returns a string representation of the weather forecast with temperature and sky condition.
     * @return A string representation of the weather forecast.
     */
    public String toString() 
    {
        return "Current condition: " + temperature + " and is " + skyCondition.toString();
    }
}
