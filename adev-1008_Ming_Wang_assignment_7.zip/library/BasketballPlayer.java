/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-04-23
* Updated: 2023-04-23
*/

/**
 * SportsTeamManager
 * @author Ming Wang
 * @version 1.0
 */
public class BasketballPlayer extends Player 
{
    private int freeThrows;
    private int fieldGoals;
    private int threePointers;

    /**
     * Constructor for BasketballPlayer with the specified name and number.
     * Initializes free throws, field goals, and three pointers to zero.
     * @param name   The basketball player's name.
     * @param number The basketball player's jersey number.
     */
    public BasketballPlayer(String name, int number) 
    {
        super(name, number);
        this.freeThrows = 0;
        this.fieldGoals = 0;
        this.threePointers = 0;
    }

    /**
     * Constructor for BasketballPlayer with the specified 
     * name, number, free throws, field goals, and three pointers.
     * @param name         The basketball player's name.
     * @param number       The basketball player's jersey number.
     * @param freeThrows   The number of free throws made by the basketball player.
     * @param fieldGoals   The number of field goals made by the basketball player.
     * @param threePointers The number of three pointers made by the basketball player.
     */
    public BasketballPlayer(String name, int number, int freeThrows, int fieldGoals, int threePointers) 
    {
        super(name, number);
        this.freeThrows = freeThrows;
        this.fieldGoals = fieldGoals;
        this.threePointers = threePointers;
    }

    /**
     * Returns the number of free throws made by the player.
     * @return The number of free throws made.
     */
    public int getFreeThrows() 
    {
        return freeThrows;
    }

    /**
     * Sets the number of free throws made by the player.
     * @param freeThrows The number of free throws made.
     */
    public void setFreeThrows(int freeThrows) 
    {
        this.freeThrows = freeThrows;
    }

    /**
     * Returns the number of field goals made by the player.
     * @return The number of field goals made.
     */
    public int getFieldGoals() 
    {
        return fieldGoals;
    }

    /**
     * Sets the number of field goals made by the player.
     * @param fieldGoals The number of field goals made.
     */
    public void setFieldGoals(int fieldGoals) 
    {
        this.fieldGoals = fieldGoals;
    }

    /**
     * Returns the number of three pointers made by the player.
     * @return The number of three pointers made.
     */
    public int getThreePointers() 
    {
        return threePointers;
    }

    /**
     * Sets the number of three pointers made by the player.
     * @param threePointers The number of three pointers made.
     */
    public void setThreePointers(int threePointers) 
    {
        this.threePointers = threePointers;
    }

    /**
     * Returns the total number of points accumulated by the player.
     * A basketball player receives one point per free throw, two points per field goal, and three points per three pointer.
     * @return The player's points.
     */
    public int getPoints() 
    {
        return freeThrows + 2 * fieldGoals + 3 * threePointers;
    }

    /**
     * Returns the String representation of the player.
     * @return A string containing the player's name, jersey number, and points.
     */
    public String toString() 
    {
        return "Basketball Player: " + super.toString() + ", Points: " + getPoints();
    }
}
