/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-04-23
* Updated: 2023-04-23
*/

/**
 * SportsTeamManager
 * @author Ming Wang
 * @version 1.0
 */
public class Player 
{
    private String name;
    private int number;

    /**
     * Initializes a new instance of the Player class with the specified name and number.
     * @param name   The player's name.
     * @param number The player's jersey number.
     */
    public Player(String name, int number) 
    {
        this.name = name;
        this.number = number;
    }

    /**
     * Returns the name of the player.
     * @return The player's name.
     */
    public String getName() 
    {
        return name;
    }

    /**
     * Sets the name of the player.
     * @param name The player's name.
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    /**
     * Returns the player's jersey number.
     * @return The player's jersey number.
     */
    public int getNumber() 
    {
        return number;
    }

    /**
     * Sets the player's jersey number.
     * @param number The player's jersey number.
     */
    public void setNumber(int number) 
    {
        this.number = number;
    }

    /**
     * Returns the total number of points accumulated by the player.
     * @return The player's points.
     */
    public int getPoints() 
    {
        return 0;
    }

    /**
     * Returns the String representation of the player.
     * @return A string containing the player's name and jersey number.
     */
    public String toString() 
    {
        return name + " [" + number + "]";
    }
}
