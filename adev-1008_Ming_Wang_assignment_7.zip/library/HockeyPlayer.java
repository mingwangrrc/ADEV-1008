/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-04-23
* Updated: 2023-04-23
*/

/**
 * SportsTeamManager
 * @author Ming Wang
 * @version 1.0
 */
/**
 * Represents a HockeyPlayer, a specialized Player.
 */
public class HockeyPlayer extends Player 
{
    private int goals;
    private int assists;

    /**
     * Initializes a new instance of the HockeyPlayer class with the specified name and number.
     * The goals and assists are set to 0.
     * @param name   The player's name.
     * @param number The player's jersey number.
     */
    public HockeyPlayer(String name, int number) 
    {
        super(name, number);
        this.goals = 0;
        this.assists = 0;
    }

    /**
     * Initializes a new instance of the HockeyPlayer class with the specified name, number, goals, and assists.
     * @param name    The player's name.
     * @param number  The player's jersey number.
     * @param goals   The number of goals scored by the player.
     * @param assists The number of assists made by the player.
     */
    public HockeyPlayer(String name, int number, int goals, int assists) 
    {
        super(name, number);
        this.goals = goals;
        this.assists = assists;
    }

    /**
     * Returns the number of goals scored by the player.
     * @return The number of goals scored.
     */
    public int getGoals() 
    {
        return goals;
    }

    /**
     * Sets the number of goals scored by the player.
     * @param goals The number of goals scored.
     */
    public void setGoals(int goals) 
    {
        this.goals = goals;
    }

    /**
     * Returns the number of assists made by the player.
     * @return The number of assists made.
     */
    public int getAssists() 
    {
        return assists;
    }

    /**
     * Sets the number of assists made by the player.
     * @param assists The number of assists made.
     */
    public void setAssists(int assists) 
    {
        this.assists = assists;
    }

    /**
     * Returns the total number of points accumulated by the player.
     * A hockey player receives one point per goal and one point per assist.
     * @return The player's points.
     */
    public int getPoints() 
    {
        return goals + assists;
    }

    /**
     * Returns the String representation of the player.
     * @return A string containing the player's name, jersey number, and points.
     */
    public String toString() 
    {
        return "Hockey Player - " + super.toString() + ", Points: " + getPoints();
    }
}
