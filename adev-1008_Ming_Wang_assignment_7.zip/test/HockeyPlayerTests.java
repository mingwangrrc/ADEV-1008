/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-04-23
* Updated: 2023-04-23
*/

/**
 * SportsTeamManager
 * @author Ming Wang
 * @version 1.0
 */
public class HockeyPlayerTests 
{

    public static void main(String[] args) 
    {
        testHockeyPlayerConstructor1();
        testHockeyPlayerConstructor2();
        testSetName();
        testSetNumber();
        testSetGoals();
        testSetAssists();
        testGetPoints();
        testToString();
    }

    private static void testHockeyPlayerConstructor1() 
    {
        HockeyPlayer player1 = new HockeyPlayer("Wayne Gretzky", 99);

        System.out.println("HockeyPlayer(String, int)");
        System.out.println("Test #1 - Initialize the name.");
        System.out.println("Expected: Wayne Gretzky");
        System.out.println("Actual: " + player1.getName());
        System.out.println();

        System.out.println("Test #2 - Initialize the number.");
        System.out.println("Expected: 99");
        System.out.println("Actual: " + player1.getNumber());
        System.out.println();

        System.out.println("Test #3 - Initialize the goals.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + player1.getGoals());
        System.out.println();

        System.out.println("Test #4 - Initialize the assists.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + player1.getAssists());
        System.out.println();
    }

    private static void testHockeyPlayerConstructor2() 
    {
        HockeyPlayer player2 = new HockeyPlayer("Sidney Crosb", 87, 20, 30);

        System.out.println("HockeyPlayer(String, int, int, int)");
        System.out.println("Test #1 - Initialize the name.");
        System.out.println("Expected: Sidney Crosb");
        System.out.println("Actual: " + player2.getName());
        System.out.println();

        System.out.println("Test #2 - Initialize the number.");
        System.out.println("Expected: 87");
        System.out.println("Actual: " + player2.getNumber());
        System.out.println();

        System.out.println("Test #3 - Initialize the goals.");
        System.out.println("Expected: 20");
        System.out.println("Actual: " + player2.getGoals());
        System.out.println();

        System.out.println("Test #4 - Initialize the assists.");
        System.out.println("Expected: 30");
        System.out.println("Actual: " + player2.getAssists());
        System.out.println();
    }

    private static void testSetName() 
    {
        HockeyPlayer player3 = new HockeyPlayer("Wayne Gretzky", 99);
        player3.setName("Mario Lemieux");

        System.out.println("setName(String)");
        System.out.println("Test #1 - Updates the state of name.");
        System.out.println("Expected: Mario Lemieux");
        System.out.println("Actual: " + player3.getName());
        System.out.println();
    }

    private static void testSetNumber() 
    {
        HockeyPlayer player4 = new HockeyPlayer("Wayne Gretzky", 99);
        player4.setNumber(66);

        System.out.println("setNumber(int)");
        System.out.println("Test #1 - Updates the state of number.");
        System.out.println("Expected: 66");
        System.out.println("Actual: " + player4.getNumber());
        System.out.println();
    }

    private static void testSetGoals() 
    {
        HockeyPlayer player5 = new HockeyPlayer("Wayne Gretzky", 99);
        player5.setGoals(25);

        System.out.println("setGoals(int)");
        System.out.println("Test #1 - Updates the state of goals.");
        System.out.println("Expected: 25");
        System.out.println("Actual: " + player5.getGoals());
        System.out.println();
    }

    private static void testSetAssists() 
    {
        HockeyPlayer player6 = new HockeyPlayer("Wayne Gretzky", 99);
        player6.setAssists(35);

        System.out.println("setAssists(int)");
        System.out.println("Test #1 - Updates the state of assists.");
        System.out.println("Expected: 35");
        System.out.println("Actual: " + player6.getAssists());
        System.out.println();
    }

    private static void testGetPoints() 
    {
        HockeyPlayer player7 = new HockeyPlayer("Wayne Gretzky", 99, 25, 35);

        System.out.println("getPoints()");
        System.out.println("Test #1 - Returns the correct number of points.");
        System.out.println("Expected: 60");
        System.out.println("Actual: " + player7.getPoints());
        System.out.println();
    }

    private static void testToString() 
    {
        HockeyPlayer player8 = new HockeyPlayer("Mario Lemieux", 66, 25, 35);

        System.out.println("toString()");
        System.out.println("Test #1 - Returns the correct String representation.");
        System.out.println("Expected: Hockey Player - Mario Lemieux [66], Points: 60");
        System.out.println("Actual: " + player8.toString());
        System.out.println();
    }
}
