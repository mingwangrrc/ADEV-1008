/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-04-23
* Updated: 2023-04-23
*/

/**
 * SportsTeamManager
 * @author Ming Wang
 * @version 1.0
 */
public class BasketballPlayerTests {

    public static void main(String[] args) {
        testBasketballPlayerConstructor1();
        testBasketballPlayerConstructor2();
        testSetName();
        testSetNumber();
        testSetFreeThrows();
        testSetFieldGoals();
        testSetThreePointers();
        testGetPoints();
        testToString();
    }
    
    private static void testBasketballPlayerConstructor1() {
        BasketballPlayer player1 = new BasketballPlayer("Michael Jordan", 23);

        System.out.println("BasketballPlayer(String, int)");
        System.out.println("Test #1 - Initialize the name.");
        System.out.println("Expected: Michael Jordan");
        System.out.println("Actual: " + player1.getName());
        System.out.println();

        System.out.println("Test #2 - Initialize the number.");
        System.out.println("Expected: 23");
        System.out.println("Actual: " + player1.getNumber());
        System.out.println();

        System.out.println("Test #3 - Initialize the free throws.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + player1.getFreeThrows());
        System.out.println();

        System.out.println("Test #4 - Initialize the field goals.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + player1.getFieldGoals());
        System.out.println();

        System.out.println("Test #5 - Initialize the three pointers.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + player1.getThreePointers());
        System.out.println();
    }

    private static void testBasketballPlayerConstructor2() {
        BasketballPlayer player2 = new BasketballPlayer("LeBron James", 6, 10, 15, 5);

        System.out.println("BasketballPlayer(String, int, int, int, int)");
        System.out.println("Test #1 - Initialize the name.");
        System.out.println("Expected: LeBron James");
        System.out.println("Actual: " + player2.getName());
        System.out.println();

        System.out.println("Test #2 - Initialize the number.");
        System.out.println("Expected: 6");
        System.out.println("Actual: " + player2.getNumber());
        System.out.println();

        System.out.println("Test #3 - Initialize the free throws.");
        System.out.println("Expected: 10");
        System.out.println("Actual: " + player2.getFreeThrows());
        System.out.println();

        System.out.println("Test #4 - Initialize the field goals.");
        System.out.println("Expected: 15");
        System.out.println("Actual: " + player2.getFieldGoals());
        System.out.println();

        System.out.println("Test #5 - Initialize the three pointers.");
        System.out.println("Expected: 5");
        System.out.println("Actual: " + player2.getThreePointers());
        System.out.println();
    }

    private static void testSetName() {
        BasketballPlayer player3 = new BasketballPlayer("Michael Jordan", 23);
        player3.setName("Kobe Bryant");

        System.out.println("setName(String)");
        System.out.println("Test #1 - Updates the state of name.");
        System.out.println("Expected: Kobe Bryant");
        System.out.println("Actual: " + player3.getName());
        System.out.println();
    }

    private static void testSetNumber() {
        BasketballPlayer player4 = new BasketballPlayer("Michael Jordan", 23);
        player4.setNumber(8);

        System.out.println("setNumber(int)");
        System.out.println("Test #1 - Updates the state of number.");
        System.out.println("Expected: 8");
        System.out.println("Actual: " + player4.getNumber());
        System.out.println();
    }

    private static void testSetFreeThrows() {
        BasketballPlayer player5 = new BasketballPlayer("Michael Jordan", 23);
        player5.setFreeThrows(12);

        System.out.println("setFreeThrows(int)");
        System.out.println("Test #1 - Updates the state of free throws.");
        System.out.println("Expected: 12");
        System.out.println("Actual: " + player5.getFreeThrows());
        System.out.println();
    }

    private static void testSetFieldGoals() {
        BasketballPlayer player6 = new BasketballPlayer("Michael Jordan", 23);
        player6.setFieldGoals(20);

        System.out.println("setFieldGoals(int)");
        System.out.println("Test #1 - Updates the state of field goals.");
        System.out.println("Expected: 20");
        System.out.println("Actual: " + player6.getFieldGoals());
        System.out.println();
    }

    private static void testSetThreePointers() {
        BasketballPlayer player7 = new BasketballPlayer("Michael Jordan", 23);
        player7.setThreePointers(8);

        System.out.println("setThreePointers(int)");
        System.out.println("Test #1 - Updates the state of three pointers.");
        System.out.println("Expected: 8");
        System.out.println("Actual: " + player7.getThreePointers());
        System.out.println();
    }

    private static void testGetPoints() 
    {
        BasketballPlayer player8 = new BasketballPlayer("Michael Jordan", 23, 10, 20, 8);
    
        System.out.println("getPoints()");
        System.out.println("Test #1 - Returns the correct number of points.");
        System.out.println("Expected: 74");
        System.out.println("Actual: " + player8.getPoints());
        System.out.println();
    }
    
    private static void testToString() 
    {
        BasketballPlayer player9 = new BasketballPlayer("Michael Jordan", 23, 10, 20, 8);
    
        System.out.println("toString()");
        System.out.println("Test #1 - Returns the correct String representation.");
        System.out.println("Expected: Basketball Player - Michael Jordan [23], Points: 74");
        System.out.println("Actual: " + player9.toString());
        System.out.println();
    }    
}
