/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-10
* Updated: 2023-01-27
*/
public class Circumference{

    public static void main(String[] args) 
    {
        //PI should be a constant
        final double PI = 3.14
        
        double radius= 3.2;
    
        double Circumference = PI*2*radius;
    
    System.out.println ( "The circumference of a circle with a radius of 3.2 is " + Circumference);
          
    }
    
    }