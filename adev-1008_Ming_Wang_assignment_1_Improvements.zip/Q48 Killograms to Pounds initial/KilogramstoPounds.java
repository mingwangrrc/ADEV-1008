/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-10
* Updated: 2023-01-13
*/
public class KilogramstoPounds {

	public static void main(String[] args) {

		double lb = 0.454;

		int kg1 = 10;

		int kg2 = 50;

		int kg3 = 100;
	
		double KilogramstoPounds1 = kg1/lb;

		double KilogramstoPounds2 = kg2/lb;

		double KilogramstoPounds3 = kg3/lb;

	System.out.println( "10 kilograms is: " + KilogramstoPounds1 + " pounds" );

	System.out.println( "50 kilograms is: " + KilogramstoPounds2 + " pounds" );

	System.out.println( "100 kilograms is: " + KilogramstoPounds3 + " pounds" );
}

}