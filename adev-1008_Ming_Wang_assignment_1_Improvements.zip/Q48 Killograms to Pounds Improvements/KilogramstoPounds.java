/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-10
* Updated: 2023-01-27
*/
public class KilogramstoPounds {

	public static void main(String[] args) {
		
		//constant for the kilogram to pound conversion
		final double POUND = 0.454;

		int Kilograms1 = 10;

		int Kilograms2 = 50;

		int Kilograms3= 100;
	
		double KilogramstoPounds1 = Kilograms1/POUND;

		double KilogramstoPounds2 = Kilograms2/POUND;

		double KilogramstoPounds3 = Kilograms3/POUND;

	System.out.println( "10 kilograms is: " + KilogramstoPounds1 + " pounds" );

	System.out.println( "50 kilograms is: " + KilogramstoPounds2 + " pounds" );

	System.out.println( "100 kilograms is: " + KilogramstoPounds3 + " pounds" );
}

}