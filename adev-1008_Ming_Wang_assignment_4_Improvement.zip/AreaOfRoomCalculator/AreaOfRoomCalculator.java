import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-17
*/

public class AreaOfRoomCalculator 
{
    
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        int length = -1;
        
        while (length != 0) 
        {
            length = getInput(in, "length");
            
            if (length != 0) 
            {
                int width = -1;
                
                while (width < 0) 
                {
                    width = getInput(in, "width");
                    
                    if (width == 0) 
                    {
                        length = 0;
                    } 
                    else if (width < 0) 
                    {
                        System.out.println("Invalid input. Please enter a positive value or 0 to exit.");
                    } 
                    else 
                    {
                        int area = calculateArea(length, width);
                        System.out.printf("The area of the room is %d.\n\n", area);
                    }
                }
            }
        }
    }
    
    public static int getInput(Scanner in, String dimension) 
    {
        int value = -1;
        
        while (value < 0) 
        {
            System.out.printf("Enter the %s of the room: ", dimension);
            value = in.nextInt();
            
            if (value < 0) 
            {
                System.out.println("Invalid input. Please enter a positive value or 0 to exit.");
            }
        }
        
        return value;
    }
    
    public static int calculateArea(int length, int width)   
    {
        return length * width;
    }
    
}

