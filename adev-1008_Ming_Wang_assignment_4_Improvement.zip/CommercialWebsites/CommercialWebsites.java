import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-17
*/

public class CommercialWebsites 
{
    public static void main(String[] args) 
    {
        
        Scanner in = new Scanner(System.in);

        // Initialize a counter to keep track of the number of commercial websites entered
        int count = 0;
    
        System.out.println("<Type \"stop\" to end the program>");
    
        // Prompt the user to enter web addresses until they type "stop"
        String input;
        do 
        {
            System.out.print("Enter a web address: ");
            input = in.nextLine().trim().toLowerCase();
    
            // Check if the input is a commercial website
            if (input.endsWith(".com") && input.length() > 4) 
            {
                count++;
            }
    
        } 
        while (!input.equals("stop"));
        System.out.printf("The number of commercial websites entered is %d.\n", count);
    }    
}