import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-02-28
* Updated: 2023-03-05
*/

public class ExamGrades 
{
    public static void main(String[] args) 
    {
        final int MAX_GRADE = 100;
        final int MIN_GRADE = 0;

        Scanner in = new Scanner(System.in);

        int sum = 0;
        int min = MAX_GRADE;
        int max = MIN_GRADE;
        for (int count = 1; count <= 10; count++) 
        {
            System.out.print("Enter grade for student: ");

            int grade = in.nextInt();

            if (grade >= MIN_GRADE && grade <= MAX_GRADE) 
            {
                sum += grade;
                if (grade < min) 
                {
                    min = grade;
                }
                if (grade > max) 
                {
                    max = grade;
                }
            } 
            else 
            {
                System.out.println("Invalid grade. Enter again.");
                count--;
            }
        }
        
        double average = (double) sum / 10;
        System.out.println("The lowest grade is " + min + ".");
        System.out.println("The highest grade is " + max + ".");
        System.out.println("The average grade is " + String.format("%.5f", average) + ".");
    }
}
