package library;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-15
* Updated: 2023-03-31
*/

/**
 * Weather Forecast Modules
 * @author Ming Wang
 * @version 1.0
 */
/**
 * The enum SkyCondition defines four possible sky conditions:
 * SUNNY, SNOWY, CLOUDY, and RAINY. These are used to represent 
 * the weather condition for the WeatherForecast class.
 * public enum SkyCondition 
 */
public enum SkyCondition 
{
    SUNNY,
    SNOWY,
    CLOUDY,
    RAINY
}
