package test;
import library.WeatherForecast;
import library.SkyCondition;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-15
* Updated: 2023-03-31
*/

/**
 * Weather Forecast Modules
 * @author Ming Wang
 * @version 1.0
 */
public class WeatherForecastTest 
{
    public static void main(String[] args) 
    {
        // Test default constructor
        WeatherForecast wf1 = new WeatherForecast();
        System.out.println("Testing default constructor:");
        System.out.println("Test #1 - Initialize the temperature.");
        System.out.println("Expected: 70");
        System.out.println("Actual: " + wf1.getTemperature());
        System.out.println();
        
        System.out.println("Test #2 - Initialize the sky condition.");
        System.out.println("Expected: SUNNY");
        System.out.println("Actual: " + wf1.getSkyCondition());
        System.out.println();

        // Test constructor with valid temperature
        WeatherForecast wf2 = new WeatherForecast(80);
        System.out.println("Testing constructor with valid temperature:");
        System.out.println("Test #3 - Initialize the temperature.");
        System.out.println("Expected: 80");
        System.out.println("Actual: " + wf2.getTemperature());
        System.out.println();
        
        System.out.println("Test #4 - Initialize the sky condition.");
        System.out.println("Expected: SUNNY");
        System.out.println("Actual: " + wf2.getSkyCondition());
        System.out.println();

        // Test constructor with temperature below minimum
        WeatherForecast wf3 = new WeatherForecast(-60);
        System.out.println("Testing constructor with temperature below minimum:");
        System.out.println("Test #5 - Initialize the temperature.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + wf3.getTemperature());
        System.out.println();
        
        System.out.println("Test #6 - Initialize the sky condition.");
        System.out.println("Expected: SUNNY");
        System.out.println("Actual: " + wf3.getSkyCondition());
        System.out.println();

        // Test constructor with temperature above maximum
        WeatherForecast wf4 = new WeatherForecast(160);
        System.out.println("Testing constructor with temperature above maximum:");
        System.out.println("Test #7 - Initialize the temperature.");
        System.out.println("Expected: 0");
        System.out.println("Actual: " + wf4.getTemperature());
        System.out.println();
        
        System.out.println("Test #8 - Initialize the sky condition.");
        System.out.println("Expected: SUNNY");
        System.out.println("Actual: " + wf4.getSkyCondition());
        System.out.println();

        // Test getTemperature method
        System.out.println("Testing getTemperature method:");
        System.out.println("Test #9 - Get the temperature.");
        System.out.println("Expected: 70");
        System.out.println("Actual: " + wf1.getTemperature());
        System.out.println();
        
        // Test setTemperature method with valid temperature
        System.out.println("Testing setTemperature method with valid temperature:");
        System.out.println("Test #10 - Set the temperature.");
        wf1.setTemperature(85);
        System.out.println("Expected: 85");
        System.out.println("Actual: " + wf1.getTemperature());
        System.out.println();
        
        // Test setTemperature method with temperature below minimum
        System.out.println("Testing setTemperature method with temperature below minimum:");
        System.out.println("Test #11 - Set the temperature.");
        wf1.setTemperature(-60);
        System.out.println("Expected: 85");
        System.out.println("Actual: " + wf1.getTemperature());
        System.out.println();

        // Test setTemperature method with temperature above maximum
        System.out.println("Testing setTemperature method with temperature above maximum:");
        System.out.println("Test #12 - Set the temperature.");
        wf1.setTemperature(160);
        System.out.println("Expected: 85");
        System.out.println("Actual: " + wf1.getTemperature());
        System.out.println();
    
        // Test getSkyCondition method
        System.out.println("Testing getSkyCondition method:");
        System.out.println("Test #13 - Get the sky condition.");
        System.out.println("Expected: SUNNY");
        System.out.println("Actual: " + wf1.getSkyCondition());
        System.out.println();
        
        // Test setSkyCondition method with valid sky condition
        System.out.println("Testing setSkyCondition method with valid sky condition:");
        System.out.println("Test #14 - Set the sky condition.");
        wf1.setSkyCondition(SkyCondition.RAINY);
        System.out.println("Expected: RAINY");
        System.out.println("Actual: " + wf1.getSkyCondition());
        System.out.println();
        
        // Test setSkyCondition method with null sky condition
        System.out.println("Testing setSkyCondition method with null sky condition:");
        System.out.println("Test #15 - Set the sky condition.");
        wf1.setSkyCondition(null);
        System.out.println("Expected: RAINY");
        System.out.println("Actual: " + wf1.getSkyCondition());
        System.out.println();

        // Test isConsistent method for too hot for snow
        System.out.println("Testing isConsistent method for too hot for snow:");
        System.out.println("Test #16 - Temperature too hot for snow.");
        wf1.setTemperature(40);
        wf1.setSkyCondition(SkyCondition.SNOWY);
        System.out.println("Expected: false");
        System.out.println("Actual: " + wf1.isConsistent());
        System.out.println();

        // Test isConsistent method for cold enough for snow
        System.out.println("Testing isConsistent method for cold enough for snow:");
        System.out.println("Test #17 - Temperature cold enough for snow.");
        wf1.setTemperature(30);
        wf1.setSkyCondition(SkyCondition.SNOWY);
        System.out.println("Expected: true");
        System.out.println("Actual: " + wf1.isConsistent());
        System.out.println();

        // Test isConsistent method for too cold for rain
        System.out.println("Testing isConsistent method for too cold for rain:");
        System.out.println("Test #18 - Temperature too cold for rain.");
        wf1.setTemperature(30);
        wf1.setSkyCondition(SkyCondition.RAINY);
        System.out.println("Expected: false");
        System.out.println("Actual: " + wf1.isConsistent());
        System.out.println();

        // Test isConsistent method for warm enough for rain
        System.out.println("Testing isConsistent method for warm enough for rain:");
        System.out.println("Test #19 - Temperature warm enough for rain.");
        wf1.setTemperature(40);
        wf1.setSkyCondition(SkyCondition.RAINY);
        System.out.println("Expected: true");
        System.out.println("Actual: " + wf1.isConsistent());
        System.out.println();

        // Test toString method
        System.out.println("Testing toString method:");
        System.out.println("Test #20 - Returns the correct String representation.");
        wf1.setTemperature(75);
        wf1.setSkyCondition(SkyCondition.CLOUDY);
        System.out.println("Expected: Current condition: 75 and is CLOUDY");
        System.out.println("Actual: " + wf1.toString());
        System.out.println();
    }
}