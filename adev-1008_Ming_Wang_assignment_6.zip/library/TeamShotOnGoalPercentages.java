/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-03-22
* Updated: 2023-04-09
*/

/**
 * TeamStatsManager
 * @author Ming Wang
 * @version 1.0
 */
public class TeamShotOnGoalPercentages 
{
    // Array to store shot on goal percentages
    private double[] percentages; 

    /**
     * Constructor that initializes the percentages array with the given number of players
     * @param numberOfPlayers - The number of players on the team
     */
    public TeamShotOnGoalPercentages(int numberOfPlayers) 
    {
        percentages = new double[numberOfPlayers];
    }

    /**
     * Constructor that initializes the percentages array with the given percentages
     * @param percentages - The shot on goal percentages for each player on the team
     * Programming Requirement: Ensure that the state of the instance is set to a copy of the array passed to this method to avoid having references to the array outside of the instance.
     */
    public TeamShotOnGoalPercentages(double[] percentages) 
    {
        this.percentages = copyPercentages(percentages);
    }

    /**
     * Method to copy the given percentages array
     * @param percentagesToCopy - The shot on goal percentages for each player on the team
     * @return A copy of the given percentages array
     */
    private double[] copyPercentages(double[] percentagesToCopy)
     {
        double[] copiedPercentages = new double[percentagesToCopy.length];
        for (int i = 0; i < percentagesToCopy.length; i++) 
        {
            copiedPercentages[i] = percentagesToCopy[i];
        }
        return copiedPercentages;
    }

    /**
     * Getter method to return a copy of the percentages array
     * @return A copy of the percentages array
     */
    public double[] getPercentages() 
    {
        return copyPercentages(percentages);
    }

    /**
     * Setter method to set the percentages array with the given percentages
     * @param percentages - The shot on goal percentages for each player on the team
     * Programming Requirement: Ensure that the state of the instance is set to a copy of the array passed to this method to avoid having references to the array outside of the instance.
     */
    public void setPercentages(double[] percentages) 
    {
        this.percentages = copyPercentages(percentages);
    }

    /**
     * Method to return the sorted percentages array in descending order
     * @return A new array containing the values of the percentages array sorted in descending order
     */
    public double[] getSortedPercentages() 
    {
        double[] sortedPercentages = copyPercentages(percentages);
        for (int i = 0; i < sortedPercentages.length - 1; i++) {
            for (int j = 0; j < sortedPercentages.length - 1 - i; j++) 
            {
                if (sortedPercentages[j] < sortedPercentages[j + 1]) 
                {
                    double temp = sortedPercentages[j];
                    sortedPercentages[j] = sortedPercentages[j + 1];
                    sortedPercentages[j + 1] = temp;
                }
            }
        }
        return sortedPercentages;
    }

    /**
     * Method to return the lowest percentage value
     * @return The value of the player with the lowest percentage in the percentages array
     */
    public double getLowestPercentage() 
    {
        double minPercentage = percentages[0];
        for (int i = 1; i < percentages.length; i++) 
        {
            if (percentages[i] < minPercentage) 
            {
                minPercentage = percentages[i];
            }
        }
        return minPercentage;
    }

    /**
     * Method to return the average of top players' percentages.
     * Formula: average = sum of top player's shot on goal percentages ÷ number of top players
     * @return The average of top players' percentages.
     */
    public double getAverageOfTopPlayers() 
    {
        double[] sortedPercentages = getSortedPercentages();
        int topPlayers = Math.min(5, sortedPercentages.length);
        double sum = 0;
        for (int i = 0; i < topPlayers; i++) 
        {
            sum += sortedPercentages[i];
        }
        return sum / topPlayers;
    }

    /**
     * Returns a string representation of the object.
     * The string contains a table of player numbers and their corresponding shot on goal percentages.
     * @return A string representation of the object.
     */
    @Override
    public String toString() 
    {
        String result = "----------------\n";
        result += "Player\tSOG%\n";
        result += "----------------\n";
        for (int i = 0; i < percentages.length; i++) 
        {
            result += (i + 1) + "\t" + String.format("%.5f", percentages[i]) + "\n";
        }
        return result;
    }
}