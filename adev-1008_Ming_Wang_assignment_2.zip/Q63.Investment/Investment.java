import java.util.Scanner;
import java.util.Locale;
import java.text.NumberFormat;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-24
* Updated: 2023-01-29
*/

public class Investment{

    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        //get amount of investment money
        System.out.print("Enter the investment amount: ");
        double investment = in.nextDouble();

        //get interest rate
        System.out.print("Enter the annual interest rate: ");
        double rate = in.nextDouble();

        //get future value of the investment in 5 years
        int years1 = 5;
        double FutureValue1 = investment * Math.pow((1 + rate), years1);

        //get future value of the investment in 10 years
        int years2 = 10;
        double FutureValue2 = investment * Math.pow((1 + rate), years2);

        //get future value of the investment in 20 years
        int years3 = 20;
        double FutureValue3 = investment * Math.pow((1 + rate), years3);

        //Canadian Currency Format
        NumberFormat canadianDollar = NumberFormat.getCurrencyInstance(Locale.CANADA);


        System.out.println("Future investment value after " + years1+ " years is: $" + canadianDollar.format(FutureValue1));

        System.out.println("Future investment value after " + years2+ " years is: $" + canadianDollar.format(FutureValue2));

        System.out.println("Future investment value after " + years3+ " years is: $" + canadianDollar.format(FutureValue3));
    }

}
