import java.util.Random;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-24
* Updated: 2023-01-29
*/

public class SmallestNumber {

    public static void main( String[] args )
    {

        Random random = new Random();

        //get Random Number between 60-100, 5 times
        int RandomNumber =  random.nextInt(41)+60;
        int RandomNumber1 = random.nextInt(41)+60;
        int RandomNumber2 = random.nextInt(41)+60;
        int RandomNumber3 = random.nextInt(41)+60;
        int RandomNumber4 = random.nextInt(41)+60;


        System.out.println( "Random Numbers: " + RandomNumber  + " " + 
                                                 RandomNumber1 + " " + 
                                                 RandomNumber2 + " " + 
                                                 RandomNumber3 + " " + 
                                                 RandomNumber4 + "." );

        //Get Smallest Number1 between first two random number
        int MinNum  = Math.min( RandomNumber, RandomNumber1 );

        //Get Smallest Number between Smallest Number1 and 3rd random Number
        int MinNum1 = Math.min( MinNum , RandomNumber2 );

        //Get Smallest Number between Smallest Number2 and 4th random Number
        int MinNum2 = Math.min( MinNum1 , RandomNumber3 );

        //Get Smallest Number between Smallest Number3 and 5th random Number
        int MinNum3 = Math.min( MinNum2 , RandomNumber4 );

        System.out.println("The smallest value is " + MinNum3 +"." );

    }

}
