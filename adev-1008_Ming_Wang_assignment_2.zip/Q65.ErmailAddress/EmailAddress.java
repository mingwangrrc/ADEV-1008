import java.util.Scanner;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-24
* Updated: 2023-01-29
*/

public class EmailAddress {

    public static void main(String[] args) 
    {

        Scanner in = new Scanner(System.in);
        
        //get email address
        System.out.print("Enter an email address: ");
        String email = in.nextLine();

        //find the position of the "@"
        int atIndex = email.indexOf("@");

        //Extract the username and domain name
        String username = email.substring(0, atIndex);
        String domain = email.substring(atIndex + 1);


        System.out.println(" The username is : " + username);
        System.out.println("The domain is : " + domain);
   
    }
    
}





