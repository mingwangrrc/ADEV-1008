import java.text.NumberFormat;
import java.util.Scanner;
import java.util.Locale;

/*
* Name: Ming Wang
* Program: Business Information Technology
* Course: ADEV-1008 Programming 1
* Created: 2023-01-24
* Updated: 2023-01-29
*/

public class ConvertDollars {

    public static void main(String[] args) 
    {
             
        Scanner in = new Scanner(System.in);

        //get quarters
        System.out.printf("Enter the number of quarters: ");
        int quarters = in.nextInt();

        //get dimes
        System.out.printf("Enter the number of dimes: ");
        int dimes = in.nextInt();
        
        //get nickels  
        System.out.printf("Enter the number of nickels: ");
        int nickels = in.nextInt();  

        //Canadian Currency Format
        NumberFormat canadianDollar = NumberFormat.getCurrencyInstance(Locale.CANADA);

        //get Amount of Money
        double amountOfMoney = ((25 * quarters) + (10 * dimes) + (5 * nickels)) / 100.0;

                     
        System.out.println("The amount of money is : "+canadianDollar.format(amountOfMoney) +".");
        
    }
    
}

